%% Script ot cacluate the power denisty of a broadband source
% need a power meter and a spectrometer sharing the same bandwidth so it can
% work.


% Data Import
% Find file names in directory
dir_name = cd;
%dir_name = '\gina_data\tile_1';
files = dir('*760*.txt');
%files = dir("gina_data\tile_5\LED_890nm_tile5_HR2B10321__6__05-57-11-243.txt");

% write to file
splitName = split(dir_name, "\");
name = splitName{end};

fileName = strcat(name,'.txt');

% Import all files in folder
for ii = 1:length(files)
    %data{ii,1} = importdata([dir_name,'\', files(ii,1).name]);
    data{ii,1} = importdata([files(ii,1).name]);
end

% extract lambda vector
Lambda=data{1,1}.data(:,1);

% background spectra
% Select intensity data for all background files
for ii = 1:10 % number of background files
    data_bg{ii,1} = data{ii+10,1}.data;
end

% Take average of background files intensity data
for jj = 1:length(data_bg{ii,1}(:,1))
    for ii = 1:length(data_bg)
        data_bg_mean{jj,:}(ii,1) = (data_bg{ii,1}(jj,2));
    end
end

for ii = 1:length(data_bg_mean)
    data_bg_mean2(ii,1) = mean(data_bg_mean{ii,1}(:,1));
end

% Light source spectra
% Select intensity data for all light source files
for ii = 1:10 % number of background files
    data_HL{ii,1} = data{ii,1}.data;
end

% figure
figure(1)
plot(Lambda,data_HL{1,1}(:,2))
xlabel('Wavelength (nm)')
ylabel('Detected counts')

%
[pks,locs,w,p] = findpeaks(data_HL{1,1}(:,2),Lambda,'MinPeakHeight',500,'MinPeakWidth',15,'Annotate','extents');
findpeaks(data_HL{1,1}(:,2),Lambda,'MinPeakHeight',500,'MinPeakWidth',15,'Annotate','extents')
title('Signal Peak Widths')

% Take average of light files intensity data
for jj = 1:length(data_HL{ii,1}(:,1))
    for ii = 1:length(data_HL)
        data_HL_mean{jj,:}(ii,1) = (data_HL{ii,1}(jj,2));
    end
end

for ii = 1:length(data_HL_mean)
    data_HL_mean2(ii,1) = mean(data_HL_mean{ii,1}(:,1));
end


% preprocessing
% subtract mean spectrum and mean background
mean_spec = data_HL_mean2 - data_bg_mean2;

% sum all intensities
mean_spec_int = sum(mean_spec);

% plot mean spectra
figure(2)
plot(Lambda,mean_spec)
xlabel('Wavelength (nm)')
ylabel('Counts')
title('Average Counts at Detector')
xlim([600 950])
ax = gca;
ax.FontSize = 25;

%%

% Weight spectrum
int_weight = mean_spec(:,:)./mean_spec_int;

% plot weighted spectra
figure(3)
plot(Lambda,int_weight)
xlabel lambda
ylabel counts

% power repartition as function of wl (in units of A)
power_weight = int_weight * 0.000001125; % value from your power measurement in Amps
% plot weighted power
figure(4)
plot(Lambda,power_weight)
xlabel lambda
ylabel A

% interpolate to wavelengths
wl = data{1,1}.data(:,1);
wl_int = 400:5:1100;
power_weight_int = interp1(wl, power_weight, wl_int, 'spline');

%% import responsivity of powermeter
% responsivity in units A/W
% replace by the responsivity of your detector
resp = importdata('powermeter.txt',',');
resp_data = resp(1:end,2);

wl_int = wl_int.';
% plot calibration curve
figure(5)
plot(wl_int,resp_data)
xlabel 'wavelength (nm)'
ylabel 'Responsivity A/W'

%% power in W/nm
% get power in Watts as function of wavelength = power repartition /
% responsivity
power_watts = power_weight_int' ./ resp_data;
figure(6)
plot(wl_int,power_watts)
xlabel 'wavelength (nm)'
ylabel 'Power (W)'
TotalPower=sum(power_watts(1:121));
%TotalPower2=trapz(wl_int(1:121),power_watts(1:121)); test to see if sum if
%good enough

%save data

% fid = fopen(fileName,'w');
% %X = cat(2,rot90(wl_int),power_watts)
% X = [wl_int(:) power_watts(:)];
% writematrix(X, fileName);


%% inverion
% this was just to check if the value measured by powermeater in Watts was
% consistant with calibration
% PowerAt600=0.00016743./resp_data(41)
% PowerAt800=0.00016743./resp_data(81)
% PowerAt900=0.00016743./resp_data(101)
%% different boundries
% %power repartition as function of wl (in units of A)
% power_weight_threshold = int_weight * 0.00016743;
% % plot weighted power
% figure
% plot(Lambda,power_weight_threshold)
% xlabel lambda
% ylabel A
% 
% % interpolate to wavelengths
% wl = data{1,1}.data(:,1);
% wl_int = 400:5:1100;
% power_weight_int = interp1(wl, power_weight_threshold, wl_int, 'spline');
% 
% % responsivity in units A/W
% resp = importdata('C:\Users\rmapfla\Desktop\Power Measurements HL2000\CalibrationS130C_500mw.xlsx');
% resp_data = resp.data(:,2);
% % plot calibration curve
% figure
% plot(wl_int,resp_data)
% xlabel lambda
% ylabel A/W
% 
% % get power in Watts as function of wavelength = power repartition /
% % responsivity
% power_watts_threshold = power_weight_int' ./ resp_data(53:136);
% figure
% plot(wl_int(53:136),power_watts_threshold)
% xlabel lambda
% ylabel W
% TotalPower=sum(power_watts_threshold)






